#include <stdio.h>
#include <string.h> //strdup(); it seems to be a copy function?
#include <ctype.h> //isdigit();
#include <stdlib.h> //malloc();, free();


#define MAXBUF 4096
#define TRUE 1
#define FALSE 0//not sure this if this value exist

//not sure the num
#define HIGHER 3
#define LOWER 1
#define SAME 2
