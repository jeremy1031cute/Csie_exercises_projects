int str2Num(char *s);
void infixToPrefix(char **tokens, int tokenLens);
void infixToPostfix(char **tokens, int tokenLens);
void postfixToInfix(char **tokens, int tokenLens);
void postfixToPrefix(char **tokens, int tokenLens);
void prefixToInfix(char **tokens, int tokenLens);
void prefixToPostfix(char **tokens, int tokenLens);

